<?php return array (
  'buscar-correo' => 'App\\Http\\Livewire\\BuscarCorreo',
);