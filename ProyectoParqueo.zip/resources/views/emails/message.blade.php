@component('mail::message')
{{$mensaje -> descripcion}}



{{ config('app.name') }}
@endcomponent