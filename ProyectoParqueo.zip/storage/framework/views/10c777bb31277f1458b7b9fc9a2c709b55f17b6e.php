
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link href="<?php echo e(asset('css/styles.css')); ?>" rel="stylesheet">

    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css" integrity="sha512-iecdLmaskl7CVkqkXNQ/ZH/XLlvWZOJyj7Yy7tcenmpD1ypASozpmT/E0iPtmFIB46ZmdtAc9eNBvH0H/ZpiBw==" crossorigin="anonymous" referrerpolicy="no-referrer" />
</head>
<?php $__env->startSection('content'); ?>

    <body>
        <div class="container-fluid mt-5">

            <div class="row">
                <div class="col-md-6 offset-md-3">
                    <h4 class="text mb-4"><i class="fa-solid fa-car-side pe-2"></i> Registro de Vehiculo</h4>
                    <div class="form-container">

                        <form action="<?php echo e(route('agregarvehiculo')); ?>" method="POST">
                            <?php echo csrf_field(); ?>
                            <?php echo method_field('POST'); ?>
                            
                            <div class="row mb-3">
                                <label for="user-type" class="col-sm-4 col-form-label text-end">Tipo de Vehiculo</label>
                                <div class="col-sm-8">
                                    <select class="form-select <?php echo e($errors->has('tipo')?'is-invalid':''); ?>" id="user-type" name="tipo">
                                        <option value="" ></option>
                                        <option value="Automovil" >Automovil</option>
                                        <option value="Motocicleta" >Motocicleta</option>
                                    </select>
                                    <?php $__errorArgs = ['tipo'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                        <div class="invalid-feedback"><?php echo e($message); ?></div>
                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                </div>
                            </div>

                            <div class="row mb-3">
                                <label for="username" class="col-sm-4 col-form-label text-end">Placa</label>
                                <div class="col-sm-8">
                                    <input type="text" name="placa" class="form-control <?php echo e($errors->has('placa')?'is-invalid':''); ?>"
                                    id="first_name" value="<?php echo e(old('placa')); ?>">

                                    <?php $__errorArgs = ['placa'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                        <div class="invalid-feedback"><?php echo e($message); ?></div>
                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                </div>
                            </div>
                            <div class="row mb-3">
                                <label for="username" class="col-sm-4 col-form-label text-end">Marca</label>
                                <div class="col-sm-8">
                                    <input type="text" name="marca" class="form-control <?php echo e($errors->has('marca')?'is-invalid':''); ?>"
                                    id="last_name" value="<?php echo e(old('marca')); ?>">

                                    <?php $__errorArgs = ['marca'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                        <div class="invalid-feedback"><?php echo e($message); ?></div>
                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                </div>
                            </div>
                            <div class="row mb-3">
                                <label for="username" class="col-sm-4 col-form-label text-end">Modelo</label>
                                <div class="col-sm-8">
                                    <input type="text" name="modelo" class="form-control <?php echo e($errors->has('modelo')?'is-invalid':''); ?>"
                                    id="username" value="<?php echo e(old('modelo')); ?>">

                                    <?php $__errorArgs = ['modelo'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                        <div class="invalid-feedback"><?php echo e($message); ?></div>
                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                </div>
                            </div>
                            <div class="row mb-3">
                                <label for="email" class="col-sm-4 col-form-label text-end">Color</label>
                                <div class="col-sm-8">
                                    <input type="text" name="color" class="form-control <?php echo e($errors->has('color')?'is-invalid':''); ?>"
                                    id="correo" value="<?php echo e(old('color')); ?>">

                                    <?php $__errorArgs = ['color'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                        <div class="invalid-feedback"><?php echo e($message); ?></div>
                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                </div>
                            </div>

                            <div class="row row-gap-3 pt-4 ">
                                <div class="col-md-6">
                                    <button type="submit" href="" class="btn btn-primary-pk btn-block w-100">Registrar</button>
                                </div>
                                <div class="col-md-6">
                                    <a href="<?php echo e(route('listavehiculo')); ?>" class="btn btn-danger-dg btn-block w-100">
                                        Cancelar
                                    </a>

                                </div>
                            </div>

                        </form>

                    </div>
                </div>
            </div>
        </div>



    </body>
    </html>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('welcome', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\ProyectoParqueo\resources\views/vehiculo/registrarvehiculo.blade.php ENDPATH**/ ?>