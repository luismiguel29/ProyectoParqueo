
<?php $__env->startSection('content'); ?>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <meta http-equiv="X-UA-Compatible" content="ie=edge">
  <link rel="stylesheet" href="<?php echo e(asset('css/Cliente/form.css')); ?>">
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css" integrity="sha512-iecdLmaskl7CVkqkXNQ/ZH/XLlvWZOJyj7Yy7tcenmpD1ypASozpmT/E0iPtmFIB46ZmdtAc9eNBvH0H/ZpiBw=="
  crossorigin="anonymous" referrerpolicy="no-referrer" />
  <title>TIS</title>
</head>
<body>
  
  <div class="container-fluid py-3">
    <div class="d-flex justify-content-center">
        <div class="col-lg-6">
            <div class="container pb-3">
                <i class="fa-solid fa-envelope fa-2xl"; style="color: 222222;
                margin-right: 10px;"></i>
                <span class="h3 ">Registrar Mensaje</span>
            </div>
            <div class="card card-outline  border-top-pk   shadow" >
                <div class="card-header">
                    <h5>Formulario</h5>
                </div>
                <form method="POST" action="<?php echo e(isset($sms)? route( 'Mensaje.editardato', ['id'=>$sms->id]) : route('MensajesGlobales.registrarMen')); ?>" style="padding: 50px 55px" >
                  <?php echo csrf_field(); ?>
                  <?php if(isset($sms)): ?>
                  <?php echo method_field('put'); ?>
                  <?php endif; ?>
                    <div class="row mb-3">
                      <label for="inputNombre3" class="col-sm-4 col-form-label text-end">Asunto</label>
                      <div class="col-sm-7">
                        <input name="asunto" class="form-control <?php echo e($errors->has('asunto')?'is-invalid':''); ?>" id="inputNombre3" value="<?php echo e(isset($sms)? $sms->asunto: old('asunto')); ?>">
                            <?php $__errorArgs = ['asunto'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                  <div class="invalid-feedback">
                                         <?php echo e($message); ?>

                                  </div>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                      </div>
                    </div>
                    <div class="row mb-3">
                        <label for="inputApellidos3" class="col-sm-4 col-form-label text-end" >Descripcion</label>
                        <div class="col-sm-7">
                          <textarea name="descripcion" class="form-control <?php echo e($errors->has('descripcion')?'is-invalid':''); ?>" id="inputApellidos3"><?php echo e(isset($sms)? $sms->descripcion: old('descripcion')); ?></textarea>
                            <?php $__errorArgs = ['descripcion'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <div class="invalid-feedback">
                                    <?php echo e($message); ?>

                                </div>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>
                      </div>
                      <div class="row row-gap-3 pt-4 ">
                        <div class="col-md-6">
                            <button type="submit" href="" class="btn btn-primary-pk btn-block w-100" >Registrar</button>
                        </div>
                        <div class="col-md-6">
                            <a type="reset" class="btn btn-danger-dg btn-block w-100"   href="<?php echo e(route('Mensaje.listamensaje')); ?>">Cancelar</a>
                        </div>
                      </div>
                  </form>
                       
            </div>
        </div>
    </div>
  </div>
</body>
</html>
<?php $__env->stopSection(); ?>


<?php echo $__env->make('welcome', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\ProyectoParqueo\resources\views/MensajesGlobales/RegistrarMensaje.blade.php ENDPATH**/ ?>