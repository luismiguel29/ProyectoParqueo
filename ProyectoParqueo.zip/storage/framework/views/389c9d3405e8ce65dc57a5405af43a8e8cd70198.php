

<?php $__env->startSection('content'); ?><!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <meta http-equiv="X-UA-Compatible" content="ie=edge">
  <link rel="stylesheet" href="<?php echo e(asset('css/Cliente/form.css')); ?>">
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css" integrity="sha512-iecdLmaskl7CVkqkXNQ/ZH/XLlvWZOJyj7Yy7tcenmpD1ypASozpmT/E0iPtmFIB46ZmdtAc9eNBvH0H/ZpiBw=="
  crossorigin="anonymous" referrerpolicy="no-referrer" />
  <title>TIS</title>
</head>
<body>
  
  <div class="container py-3">
    <div class="d-flex justify-content-center">
        <div class="col-lg-6">
            <div class="container pb-3">
                <i class="fa-solid fa-user fa-2xl"; style="color: 222222;
                margin-right: 10px;"></i>
                <span class="h3 ">Registrar Usuario Cliente</span>
            </div>
            <div class="card card-outline  border-top-pk   shadow" >
                <div class="card-header">
                    <h5>Formulario</h5>
                </div>
                <form method="POST" action="<?php echo e(isset($user)? route( 'Cliente.editardato', ['id'=>$user->id]) : route('Cliente.guardar')); ?>" style="padding: 50px 55px" >
                  <?php echo csrf_field(); ?>
                  <?php if(isset($user)): ?>
                  <?php echo method_field('put'); ?>
                  <?php endif; ?>
                    <div class="row mb-3">
                      <label for="inputNombre3" class="col-sm-4 col-form-label text-end">Nombre</label>
                      <div class="col-sm-7">
                        <input name="nombre" class="form-control <?php echo e($errors->has('nombre')?'is-invalid':''); ?>" id="inputNombre3" value="<?php echo e(isset($user)? $user->nombre: old('nombre')); ?>">
                            <?php $__errorArgs = ['nombre'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                  <div class="invalid-feedback">
                                         <?php echo e($message); ?>

                                  </div>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                      </div>
                    </div>
                    <div class="row mb-3">
                        <label for="inputApellidos3" class="col-sm-4 col-form-label text-end" >Apellidos</label>
                        <div class="col-sm-7">
                          <input name="apellido" class="form-control <?php echo e($errors->has('apellido')?'is-invalid':''); ?>" id="inputApellidos3" value="<?php echo e(isset($user)? $user->apellido: old('apellido')); ?>">
                          <?php $__errorArgs = ['apellido'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                          <div class="invalid-feedback">
                              <?php echo e($message); ?>

                          </div>
                      <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>
                      </div>
                      <div class="row mb-3">
                        <label for="inputUsuario3" class="col-sm-4 col-form-label text-end">Usuario</label>
                        <div class="col-sm-7">
                          <input name="usuario" class="form-control <?php echo e($errors->has('usuario')?'is-invalid':''); ?>" id="inputUsuario3" value="<?php echo e(isset($user)? $user->usuario: old('usuario')); ?>">
                          <?php $__errorArgs = ['usuario'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                          <div class="invalid-feedback">
                              <?php echo e($message); ?>

                          </div>
                          <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>
                      </div>
                      <div class="row mb-3">
                        <label for="inputCedula3" class="col-sm-4 col-form-label text-end">Cedula</label>
                        <div class="col-sm-7">
                          <input name="ci" class="form-control <?php echo e($errors->has('ci')?'is-invalid':''); ?>" id="inputCedula3" value="<?php echo e(isset($user)? $user->ci: old('ci')); ?>">
                          <?php $__errorArgs = ['ci'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                          <div class="invalid-feedback">
                              <?php echo e($message); ?>

                          </div>
                          <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>
                      </div>
                      <div class="row mb-3">
                        <label for="inputTelefono3" class="col-sm-4 col-form-label text-end">Telefono</label>
                        <div class="col-sm-7">
                          <input name="telefono" class="form-control <?php echo e($errors->has('telefono')?'is-invalid':''); ?>" id="inputTelefono3" value="<?php echo e(isset($user)? $user->telefono: old('telefono')); ?>">
                          <?php $__errorArgs = ['telefono'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                          <div class="invalid-feedback">
                              <?php echo e($message); ?>

                          </div>
                          <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>
                      </div>
                      <div class="row mb-3">
                        <label for="inputCorreo3" class="col-sm-4 col-form-label text-end">Correo</label>
                        <div class="col-sm-7">
                          <input name="correo" class="form-control <?php echo e($errors->has('correo')?'is-invalid':''); ?>" id="inputCorreo3" value="<?php echo e(isset($user)? $user->correo: old('correo')); ?>">
                          <?php $__errorArgs = ['correo'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                          <div class="invalid-feedback">
                              <?php echo e($message); ?>

                          </div>
                          <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>
                      </div>
                      <?php if(!isset ($user )): ?>
                        
                      <div class="row mb-3">
                        <label for="inputContraseña3" class="col-sm-4 col-form-label text-end">Contraseña</label>
                        <div class="col-sm-7">
                          <input name="contraseña" class="form-control <?php echo e($errors->has('contraseña')?'is-invalid':''); ?>" id="inputContraseña3" value="<?php echo e(isset($user)? $user->contraseña: old('contraseña')); ?>">
                          
                          <?php $__errorArgs = ['contraseña'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                          <div class="invalid-feedback">
                              <?php echo e($message); ?>

                          </div>
                          <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>
                      </div>
                      <?php endif; ?>
                      <!--<div class="row mb-3">
                        <label for="inputRepetirContraseña3" class="col-sm-4 col-form-label text-end">Repetir Contraseña</label>
                        <div class="col-sm-7">
                          <input name="repetirContraseña" class="form-control" id="inputRepetirContraseña3" value="<?php echo e(isset($user)? $user->repetirContraseña: old('repetirContraseña')); ?>">
                        </div>
                      </div>-->
                      <!--<div class="row mb-3">
                        <label for="inputTipoDeVehiculo3" class="col-sm-4 col-form-label text-end">Tipo de Vehiculo</label>
                        <div class="col-sm-7">
                        <select name="tipo_vehiculo" class="form-select <?php echo e($errors->has('tipo_vehiculo')?'is-invalid':''); ?>" aria-label="Default select example">
                                <option <?php echo e(isset($user)? 'selected':""); ?>>Seleccione una opcion</option>
                                <option value="movilidad" <?php echo e((isset($user)&& $user->tipo_vehiculo =="movilidad" )? 'selected':''); ?>>Movilidad</option>
                                <option value="motocicleta" <?php echo e((isset($user)&& $user->tipo_vehiculo =="motocicleta" )? 'selected':''); ?>>Motocicleta</option>
                              </select>
                        </div>
                      </div>-->
                      <!--<div class="row mb-3">
                        <label for="inputNumeroDePlaca3" class="col-sm-4 col-form-label text-end">Numero de placa</label>
                        <div class="col-sm-7">
                          <input name="placa" class="form-control <?php echo e($errors->has('placa')?'is-invalid':''); ?>" id="inputNumeroDePlaca3" value="<?php echo e(isset($user)? $user->placa: old('placa')); ?>">
                          <?php $__errorArgs = ['placa'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                          <div class="invalid-feedback">
                              <?php echo e($message); ?>

                          </div>
                          <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>
                      </div>-->
                     <!-- <div class="row mb-3">
                        <label for="inputMarca3" class="col-sm-4 col-form-label text-end">Marca</label>
                        <div class="col-sm-7">
                          <input name="marca" class="form-control <?php echo e($errors->has('marca')?'is-invalid':''); ?>" id="inputMarca3" value="<?php echo e(isset($user)? $user->marca: old('marca')); ?>">
                          <?php $__errorArgs = ['marca'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                          <div class="invalid-feedback">
                              <?php echo e($message); ?>

                          </div>
                          <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>
                      </div>-->
                      <!--<div class="row mb-3">
                        <label for="inputColor3" class="col-sm-4 col-form-label text-end">Color</label>
                        <div class="col-sm-7">
                          <input name="color" class="form-control <?php echo e($errors->has('color')?'is-invalid':''); ?>" id="inputColor3" value="<?php echo e(isset($user)? $user->color: old('color')); ?>">
                          <?php $__errorArgs = ['color'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                          <div class="invalid-feedback">
                              <?php echo e($message); ?>

                          </div>
                          <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>
                      </div>-->
                    <!--<div class="row mb-3">
                      <label for="inputModelo3" class="col-sm-4 col-form-label text-end">Modelo</label>
                      <div class="col-sm-7">
                        <input name="modelo" class="form-control <?php echo e($errors->has('modelo')?'is-invalid':''); ?>" id="inputModelo3" value="<?php echo e(isset($user)? $user->modelo: old('modelo')); ?>">
                        <?php $__errorArgs = ['modelo'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                          <div class="invalid-feedback">
                              <?php echo e($message); ?>

                          </div>
                          <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                      </div>
                    </div>-->
  
                    <div class="row row-gap-3 pt-4 ">
                      <div class="col-md-6">
                          <button type="submit" href="" class="btn btn-primary-pk btn-block w-100" >Registrar</button>
                      </div>
                      <div class="col-md-6">
                          <a type="reset" class="btn btn-danger-dg btn-block w-100"   href="<?php echo e(route('Cliente.listacliente')); ?>">Cancelar</a>
                      </div>
                    </div>
  
                  </form>
                       
            </div>
        </div>
    </div>
  </div>
</body>
</html>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('welcome', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\ProyectoParqueo\resources\views/Cliente/ClienteForm.blade.php ENDPATH**/ ?>