
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Tabla de Usuarios</title>
    <link href="<?php echo e(asset('css/stylesV.css')); ?>" rel="stylesheet">

    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css"
        integrity="sha512-iecdLmaskl7CVkqkXNQ/ZH/XLlvWZOJyj7Yy7tcenmpD1ypASozpmT/E0iPtmFIB46ZmdtAc9eNBvH0H/ZpiBw=="
        crossorigin="anonymous" referrerpolicy="no-referrer" />
    <title>Tarjeta pequeña</title>

</head>
<?php $__env->startSection('content'); ?>

    <body>
        <style>
            .wordwrap {
                word-wrap: break-word;
                max-width: 400px; //ajusta este valor como necesites
            }
        </style>
        <style>
            .search-form {
                width: 50%;
                margin-bottom: 20px;
            }
        </style>
        <div class="container mt-5">
            <?php echo csrf_field(); ?>
            <?php if(session('success')): ?>
                <div class="alert alert-success">
                    <?php echo e(session('success')); ?>

                </div>
            <?php endif; ?>
            <div class="d-flex justify-content-between align-items-center mb-4">
                <h4 class="text mb-0"><i class="fas fa-book pe-2"></i> Reclamos</h4>

            </div>
            <form method="" action="" class="search-form">
                <div class="input-group">
                    <input type="text" name="search" class="form-control" placeholder="Buscar por tipo Reclamo/usuario" value="<?php echo e(request()->query('search')); ?>">
                    <span class="input-group-btn">
                        <button type="submit" class="btn btn-primary">Buscar</button>
                    </span>
                </div>
            </form>

            <div class="table-responsive" id="table-container">
                <div class="blue-line"></div>
                <table class="table">
                    <thead>
                        <tr>
                            <th>tipo</th>
                            <th>Usuario</th>
                            <th>Descripción</th>
                            <th>Fecha</th>
                            <?php if(session()->get('sesion')->rol == 'administrador' || session()->get('sesion')->rol == 'secretaria'): ?>
                                <th>Acción</th>
                            <?php endif; ?>
                        </tr>
                    </thead>
                    <tbody>
                        <?php $__currentLoopData = $solicitudes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $solicitud): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <td><?php echo e($solicitud->tipo); ?></td>
                                <td><?php echo e($solicitud->usuario); ?></td>

                                <td class="wordwrap">
                                    <!-- Versión corta de la descripción -->
                                    <div id="short-description-<?php echo e($solicitud->id); ?>">
                                        <?php echo e(\Illuminate\Support\Str::limit($solicitud->descripcion, 50, '...')); ?>

                                        <!-- Limita la descripción a 50 caracteres -->
                                        <?php if(strlen($solicitud->descripcion) > 50): ?>
                                            <button class="btn btn-link p-0 m-0 align-baseline"
                                                onclick="showFullDescription(<?php echo e($solicitud->id); ?>)">ver más</button>
                                        <?php endif; ?>
                                    </div>

                                    <!-- Versión completa de la descripción -->
                                    <div id="full-description-<?php echo e($solicitud->id); ?>" style="display: none;">
                                        <?php echo e($solicitud->descripcion); ?>

                                        <?php if(strlen($solicitud->descripcion) > 50): ?>
                                            <button class="btn btn-link p-0 m-0 align-baseline"
                                                onclick="hideFullDescription(<?php echo e($solicitud->id); ?>)">ver menos</button>
                                        <?php endif; ?>
                                    </div>
                                </td>

                                <td><?php echo e($solicitud->fecha); ?></td>
                                <?php if(session()->get('sesion')->rol == 'administrador' || session()->get('sesion')->rol == 'secretaria'): ?>
                                    <td>
                                        <!-- Aquí irían los botones y modales -->
                                        <!-- Botón eliminar que abre el modal -->
                                        

                                        <button type="button" class="btn btn-danger btn-sm" data-bs-toggle="modal"
                                            data-bs-target="#deleteModal-<?php echo e($solicitud->id); ?>">
                                            <i class="fas fa-trash-alt"></i>
                                        </button>



                                        <!-- Modal de confirmación de eliminación -->
                                        <div class="modal fade" id="deleteModal-<?php echo e($solicitud->id); ?>" tabindex="-1"
                                            aria-labelledby="deleteModalLabel" aria-hidden="true">
                                            <div class="modal-dialog">
                                                <div class="modal-content">
                                                    <div class="modal-header">
                                                        <h5 class="modal-title" id="deleteModalLabel">Confirmar eliminación
                                                        </h5>
                                                        <button type="button" class="btn-close" data-bs-dismiss="modal"
                                                            aria-label="Close"></button>
                                                    </div>
                                                    <div class="modal-body">
                                                        ¿Estás seguro de que quieres eliminar la solicitud
                                                        <?php echo e($solicitud->id); ?>?
                                                    </div>
                                                    <div class="modal-footer">
                                                        <button type="button" class="btn btn-secondary"
                                                            data-bs-dismiss="modal">Cancelar</button>
                                                        <form action="<?php echo e(route('solicitudes.destroy', $solicitud->id)); ?>"
                                                            method="POST">
                                                            <?php echo csrf_field(); ?>
                                                            <?php echo method_field('DELETE'); ?>
                                                            <button type="submit" class="btn btn-danger">Eliminar</button>
                                                        </form>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                        <!-- Modal de confirmación -->
                                        

                                    </td>
                                <?php endif; ?>
                            </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
                </table>
            </div>
        </div>
        <script>
            function showFullDescription(id) {
                document.getElementById('short-description-' + id).style.display = 'none';
                document.getElementById('full-description-' + id).style.display = 'block';
            }

            function hideFullDescription(id) {
                document.getElementById('short-description-' + id).style.display = 'block';
                document.getElementById('full-description-' + id).style.display = 'none';
            }
        </script>
        <script>
            function openModal() {
                $('#myModal').modal('show');
            }
        </script>
    </body>

    </html>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('welcome', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\ProyectoParqueo\resources\views/registro/VerReclamo.blade.php ENDPATH**/ ?>