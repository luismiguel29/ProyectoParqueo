
<?php $__env->startSection('content'); ?>

    <!DOCTYPE html>
    <html lang="en">

    <head>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <meta http-equiv="X-UA-Compatible" content="ie=edge">
        <link rel="stylesheet" href="<?php echo e(asset('css/luiscss/login.css')); ?>">
        <link rel="stylesheet" href="<?php echo e(asset('css/luiscss/horario.css')); ?>">
        <link rel="stylesheet" href="<?php echo e(asset('css/luiscss/boton.css')); ?>">
    </head>

    <body>
        <div class="container py-3">
            <div class="row">
                <div class="col-lg-6">
                    <div class="containera pb-3">
                        <i class="fa-solid fa-clock fa-2x pe-1"></i>
                        <span class="h3 ">Creación de horarios</span>
                    </div>


                    <form action="<?php echo e(route('horario.store')); ?>" method="post">
                        <?php echo csrf_field(); ?>

                        


                        <div class="card card-outline  border-top-pk   shadow">
                            <div class="row overflow-hidden">
                                <div class="col p-3">
                                    <label for="validate" class="p-2" for="">Hora de inicio</label>
                                    <input class="form-control <?php echo e($errors->has('h_apertura')?'is-invalid':''); ?>" id="validate" type="time" name="h_apertura" value="<?php echo e(old('h_apertura')); ?>">
                                    <?php $__errorArgs = ['h_apertura'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                        <div class="invalid-feedback"><?php echo e($message); ?></div>
                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                </div>

                                <div class="col p-3">
                                    <label class="p-2" for="">Hora de cierre</label>
                                    <input class="form-control <?php echo e($errors->has('h_cierre')?'is-invalid':''); ?>" type="time" name="h_cierre" value="<?php echo e(old('h_cierre')); ?>">
                                    <?php $__errorArgs = ['h_cierre'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                        <div class="invalid-feedback"><?php echo e($message); ?></div>
                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                </div>
                                <div class="col p-3">
                                    <label class="p-2" for="">Día</label>
                                    <select class="form-select <?php echo e($errors->has('dia')?'is-invalid':''); ?>" id="" name="dia">
                                        <option value="">Selecionar</option>
                                        <option value="Lunes">Lunes</option>
                                        <option value="Martes">Martes</option>
                                        <option value="Miercoles">Miercoles</option>
                                        <option value="Jueves">Jueves</option>
                                        <option value="Viernes">Viernes</option>
                                        <option value="Sabado">Sabado</option>
                                        <option value="Domingo">Domingo</option>
                                    </select>
                                    <?php $__errorArgs = ['dia'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                        <div class="invalid-feedback"><?php echo e($message); ?></div>
                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                </div>

                            </div>
                            <div class="btn-group">
                                <div class="col d-grid p-3">
                                    <button type="submit" class="btn btn-primary-pk"
                                        >Registrar</button>
                                </div>
                                <div class="col d-grid p-3">
                                    <a href="<?php echo e(route('lista')); ?>" class="btn btn-danger-dg"
                                        >Cancelar</a>
                                </div>
                            </div>
                        </div>
                    </form>

                </div>

            </div>
        </div>
    </body>

    </html>


<?php $__env->stopSection(); ?>

<?php echo $__env->make('welcome', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\ProyectoParqueo\resources\views/horario/horario.blade.php ENDPATH**/ ?>