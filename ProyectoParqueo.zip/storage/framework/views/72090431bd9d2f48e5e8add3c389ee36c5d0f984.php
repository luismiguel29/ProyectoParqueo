
<?php $__env->startSection('content'); ?>
    <!DOCTYPE html>
    <html lang="en">

    <head>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <meta http-equiv="X-UA-Compatible" content="ie=edge">
        <link rel="stylesheet" href="<?php echo e(asset('css/luiscss/login.css')); ?>">
        <link rel="stylesheet" href="<?php echo e(asset('css/luiscss/horario.css')); ?>">
        <link rel="stylesheet" href="<?php echo e(asset('css/luiscss/boton.css')); ?>">
    </head>

    <body>
        <div class="container py-3">
            <div class="row">
                <div class="col">
                    <div class="containera pb-3">
                        <i class="fa-solid fa-gear fa-2x"></i>
                        <span class="h3 ">Configuración</span>
                    </div>
                    <?php if(session('success')): ?>
                        <div class="alert alert-success">
                            <?php echo e(session('success')); ?>

                        </div>
                    <?php endif; ?>
                    <?php if(session('message')): ?>
                        <div class="alert alert-danger">
                            <?php echo e(session('message')); ?>

                        </div>
                    <?php endif; ?>
                    <form action="<?php echo e(route('modificarConfiguracion')); ?>" method="POST">
                        <?php echo csrf_field(); ?>
                        <input type="hidden" name="enUsoTarifa" value="<?php echo e($enUsoTarifa->id); ?>">
                        <input type="hidden" name="enUsoConf" value="<?php echo e($enUsoConf->id); ?>">
                        <div class="card card-outline  border-top-pk   shadow p-3">
                            <div class="row">
                                <label class="" for="">
                                    <h5>Tarifa:</h5>
                                </label>
                                <div class="col-sm-6">
                                    <select class="form-select" name="tarifa" id="">
                                        <?php $__currentLoopData = $tarifa; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <option <?php if($item->estado == 1): ?> selected <?php endif; ?>
                                                value="<?php echo e($item->id); ?>"><?php echo e($item->nombre); ?> - Monto bs.
                                                <?php echo e($item->precio); ?></option>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </select>
                                </div>
                            </div>
                            <div class="row">
                                <label class="mt-2" for="">
                                    <h5>Fecha limite de pago:</h5>
                                </label>
                                <div class="col-sm-6">
                                    <select class="form-select" name="fecha" id="">
                                        <?php $__currentLoopData = $configuracion; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item2): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <option <?php if($item2->estado == 1): ?> selected <?php endif; ?>
                                                value="<?php echo e($item2->id); ?>"><?php echo e($item2->dia); ?>, <?php echo e($item2->nombre); ?></option>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </select>
                                </div>
                            </div>
                            <div class="row">
                                <div class="col-sm-6">
                                    <div class="mt-3">
                                        <div class="col-sm-6 mx-auto d-grid p-3">
                                            <button type="submit" class="btn btn-primary-pk">Guardar cambios</button>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div class="row">
                                <a href="<?php echo e(route('notificarMora')); ?>" class="btn-primary-pk">Mora</a>
                            </div>
                        </div>
                    </form>

                </div>

            </div>
        </div>
    </body>

    </html>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('welcome', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\ProyectoParqueo\resources\views/configuracion/vistaConf.blade.php ENDPATH**/ ?>