<!doctype html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, user-scalable=no, initial-scale=1.0">
</head>
<body>
    <h1><?php echo e($asunto); ?></h1>
    <h3><?php echo e($descripcion); ?></h3>
</body>
</html><?php /**PATH C:\laragon\www\ProyectoParqueo\resources\views/emails/moraporpago.blade.php ENDPATH**/ ?>