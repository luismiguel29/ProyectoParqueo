
<form action="<?php echo e(route('MensajesGlobales.send')); ?>" method="post">
    <?php echo csrf_field(); ?>
    <input id="mensajeCorreo" name="id" hidden>
    <select  name="user" class="js-example-basic-single">
        
        <?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <option value="<?php echo e($user['id']); ?>"><?php echo e($user['nombre']); ?></option>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </select>
    <div class="modal-footer">
        <button  class="btn btn-primary-pk">Enviar</button>
        <button type="button" class="btn  btn-danger-dg" data-bs-dismiss="modal">Cancelar</button>
        
    </div>
</form>
<?php /**PATH C:\laragon\www\ProyectoParqueo\resources\views/livewire/buscar-correo.blade.php ENDPATH**/ ?>