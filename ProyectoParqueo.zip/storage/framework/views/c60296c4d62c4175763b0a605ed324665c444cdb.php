
<?php $__env->startSection('content'); ?>
    <!DOCTYPE html>
    <html lang="es">

    <head>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <meta http-equiv="X-UA-Compatible" content="ie=edge">
        <link rel="stylesheet" href="<?php echo e(asset('css/luiscss/horario.css')); ?>">
        <link rel="stylesheet" href="<?php echo e(asset('css/luiscss/listahorario.css')); ?>">
        <link rel="stylesheet" href="<?php echo e(asset('css/luiscss/boton.css')); ?>">

        <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
        <link href="https://cdn.jsdelivr.net/npm/select2@4.1.0-beta.1/dist/css/select2.min.css" rel="stylesheet" />
        <script src="https://cdn.jsdelivr.net/npm/select2@4.1.0-beta.1/dist/js/select2.min.js"></script>
    </head>

    <body>
        <div class="container-fluid py-3">
            <?php if(session('message')): ?>
                <div class="alert alert-danger">
                    <?php echo e(session('message')); ?>

                </div>
            <?php endif; ?>
            <div class="row">
                <div class="row">
                    <div class="col">
                        <i class="fa-solid fa-handshake fa-2x pe-2"></i>
                        <span class="h3 ">Gestión compartir sitio</span>
                    </div>
                    <form action="<?php echo e(route('agregarusuario', $parqueo->id)); ?>" method="POST">
                        <?php echo csrf_field(); ?>
                        <?php echo method_field('PUT'); ?>
                        <div class="row mt-2 p-2" style="">
                            <div class="col col-sm-3 p-2">
                                <select class="livesearch form-control <?php echo e($errors->has('livesearch') ? 'is-invalid' : ''); ?>"
                                    name="livesearch" ></select>
                                <?php $__errorArgs = ['livesearch'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <div class="invalid-feedback"><?php echo e($message); ?></div>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>

                            <div class="col-sm p-2 text-end">
                                <button type="submit" class="btn btn-primary-pk" href="" <?php if($parqueo->invitado > 0): ?> disabled <?php endif; ?>><i class="fa-solid fa-plus"
                                        style="" ></i>
                                    Compartir</button>
                            </div>
                        </div>
                    </form>

                    <div class="table-responsive card card-outline  border-top-pk   shadow">
                        <?php if($parqueo->invitado > 0): ?>
                            <table class="table table-striped mt-3 ">
                                <thead class="p-3">
                                    <tr>
                                        <th>Sitio</th>
                                        <th>Zona</th>
                                        <th>Invitado</th>
                                        <th>Acción</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <tr>
                                        <td><?php echo e($parqueo->sitio); ?></td>
                                        <td><?php echo e($parqueo->zona); ?></td>
                                        <td><?php echo e($parqueo->invitados->nombre); ?> <?php echo e($parqueo->invitados->apellido); ?></td>
                                        <td>
                                            <div class="d-inline-block">
                                                <button type="button" class="bicon icon--red" data-bs-toggle="modal"
                                                    data-bs-target="#exampleModal">
                                                    <i class="fa-solid fa-trash-can icon--white"></i>
                                                </button>
                                            </div>

                                            <!-- Modal -->
                                            <div class="modal fade" id="exampleModal"
                                                aria-hidden="true">
                                                <div class="modal-dialog">
                                                    <div class="modal-content">
                                                        <div class="modal-header">
                                                            <h1 class="modal-title fs-5" id="exampleModalLabel">
                                                                ¡Atención!
                                                            </h1>
                                                            <button type="button" class="btn-close"
                                                                data-bs-dismiss="modal" aria-label="Close"></button>
                                                        </div>
                                                        <div class="modal-body">Esta seguro de eliminar el usuario con el que comparte el sitio?
                                                        </div>
                                                        <div class="modal-footer">
                                                            <button type="button" class="btn btn-primary-pk"
                                                                data-bs-dismiss="modal">Cerrar</button>
                                                            

                                                            <form action="<?php echo e(route('eliminarusuario', $parqueo->id)); ?>" method="POST">
                                                                <?php echo csrf_field(); ?>
                                                                <?php echo method_field('PUT'); ?>
                                                                <button type="submit" class="btn btn-danger-dg"
                                                                style="">Eliminar</button>
                                                            </form>

                                                        </div>
                                                    </div>
                                                </div>
                                            </div>

                                        </td>
                                    </tr>
                                </tbody>
                            </table>
                        <?php else: ?>
                            <div class="alert alert-dark">Actualmente no comparte sitio con ningun usuario</div>
                        <?php endif; ?>
                    </div>
                </div>
            </div>
        </div>


        <script type="text/javascript">
            $('.livesearch').select2({
                placeholder: 'Buscar usuario',
                ajax: {
                    url: '/buscarusuario',
                    dataType: 'json',
                    delay: 250,
                    processResults: function(data) {
                        return {
                            results: $.map(data, function(item) {
                                return {
                                    text: item.nombre+" "+item.apellido,
                                    id: item.id,
                                }

                            })
                        };
                    },
                    cache: true
                }
            });
        </script>
    </body>


    </html>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('welcome', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\ProyectoParqueo\resources\views/vehiculo/compartirSitio.blade.php ENDPATH**/ ?>