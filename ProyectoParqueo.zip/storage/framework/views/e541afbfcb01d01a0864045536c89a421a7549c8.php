<?php $__env->startComponent('mail::message'); ?>
<?php echo e($mensaje -> descripcion); ?>




<?php echo e(config('app.name')); ?>

<?php echo $__env->renderComponent(); ?><?php /**PATH C:\laragon\www\ProyectoParqueo\resources\views/emails/message.blade.php ENDPATH**/ ?>