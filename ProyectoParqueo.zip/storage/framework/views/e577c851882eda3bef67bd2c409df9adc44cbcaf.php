<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">

    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha3/dist/css/bootstrap.min.css" rel="stylesheet"
        integrity="sha384-KK94CHFLLe+nY2dmCWGMq91rCGa5gtU4mk92HdvYe+M/SXH301p5ILy+dN9+nJOZ" crossorigin="anonymous">

    <link rel="stylesheet" href="<?php echo e(asset('css/app.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('css/ConfiguracionParqueo/verParqueo.css')); ?>">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css"
        integrity="sha512-iecdLmaskl7CVkqkXNQ/ZH/XLlvWZOJyj7Yy7tcenmpD1ypASozpmT/E0iPtmFIB46ZmdtAc9eNBvH0H/ZpiBw=="
        crossorigin="anonymous" referrerpolicy="no-referrer" />
    <title>Document</title>
</head>

<body>

    
    <?php $__env->startSection('content'); ?>
        <div class="container py-3 grl-site">
            <div class="row">
                <div class="col-lg-12">
                    <div container class="d-flex justify-content-between column-gap-3">
                        <div class="container pb-3">
                            <i class="fa-solid fa-car-side fa-2x pe-1"></i>
                            <span class="h3 ">Ver Sitios ZONA A</span>
                        </div>
                        <!--DROPDOWN INICIO-->
                        <div class="dropdown">
                            <button class="btn btn-primary dropdown-toggle" type="button" data-bs-toggle="dropdown"
                                aria-expanded="false">
                                Mapas
                            </button>
                            <ul class="dropdown-menu" style="">
                                <li><a class="dropdown-item" href='/mapaA'>Mapa A</a></li>
                                <li><a class="dropdown-item" href='/mapaB'>Mapa B</a></li>
                            </ul>
                        </div>
                        <div class="dropdown">
                            <button class="btn btn-primary dropdown-toggle" type="button" data-bs-toggle="dropdown"
                                aria-expanded="false">
                                Zonas
                            </button>
                            <ul class="dropdown-menu" style="">
                                <li><a class="dropdown-item" href="<?php echo e(route('verparqueo')); ?>">Zona A</a></li>
                                <li><a class="dropdown-item" href="<?php echo e(route('verparqueozonab')); ?>">Zona B</a></li>
                            </ul>
                        </div>
                        <!--DROPDOWN FIN-->
                    </div>

                    <!--CARD-->

                    <div class="card card-outline  border-top-pk   shadow">
                        <div class="card-header">
                            <h5>Parqueo</h5>
                        </div>
                        <div class="container">
                            <div class="row mx-1 gap-3">
                                <?php $__currentLoopData = $datosA; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $dato): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <div class="car" type="submit" class="bicon icon--blue" data-bs-toggle="modal" data-bs-target="#modal-update-<?php echo e($dato->id); ?>">
                                        <p class="h3 text-center"><?php echo e($dato->sitio); ?></p>
                                        <div class="car-content rounded-2 bg-<?php echo e($dato->estado == 1 ? 'danger-pk' : 'primary-pk'); ?> text-light d-flex align-items-center justify-content-center flex-column">
                                            <i class="fa-solid fa-<?php echo e($dato->estado == 1 ? 'car' : 'square-caret-up'); ?> fa-3x"></i>
                                        </div>
                                        <p class="fs-6 text-center"><?php echo e($dato->estado == 1 ? 'Ocupado' : 'Libre'); ?></p>
                                    </div>
                                    <?php echo $__env->make('ConfiguracionParqueo.sendRequest', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                                
                            </div>
                        </div>



                    </div>

                </div>


            </div>
        </div>
    <?php $__env->stopSection(); ?>

</body>

</html>

<?php echo $__env->make('welcome', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\ProyectoParqueo\resources\views//ConfiguracionParqueo/VerParqueo.blade.php ENDPATH**/ ?>