
<?php $__env->startSection('content'); ?>
    <!DOCTYPE html>
    <html lang="en">

    <head>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <meta http-equiv="X-UA-Compatible" content="ie=edge">
        <link rel="stylesheet" href="<?php echo e(asset('css/luiscss/horario.css')); ?>">
        <link rel="stylesheet" href="<?php echo e(asset('css/luiscss/listahorario.css')); ?>">
        <link rel="stylesheet" href="<?php echo e(asset('css/luiscss/boton.css')); ?>">
    </head>

    <body>
        <div class="container-fluid py-3">
            <div class="row">
                <div class="row">
                    <div class="col p-3">
                        <i class="fa-solid fa-calendar-days fa-2x pe-2"></i>
                        <span class="h3 ">Historial de reportes</span>
                    </div>
                    <form action="<?php echo e(route('buscarHistorial')); ?>" method="GET">
                    
                        <?php echo csrf_field(); ?>
                        <div class="row p-3">
                            <div class="col-sm-2">
                                <label for="">Hora de inicio</label>
                                <input class="form-control <?php echo e($errors->has('fechaini')?'is-invalid':''); ?>" type="date" name="fechaini" value=" <?php echo e(old('fechaini')); ?>">
                                <?php $__errorArgs = ['fechaini'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <div class="invalid-feedback"><?php echo e($message); ?></div>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>
                            <div class="col-sm-2">
                                <label for="">Hora final</label>
                                <input class="form-control <?php echo e($errors->has('fechafin')?'is-invalid':''); ?>" type="date" name="fechafin" value=" <?php echo e(old('fechafin')); ?>">
                                <?php $__errorArgs = ['fechafin'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <div class="invalid-feedback"><?php echo e($message); ?></div>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>
                            <div class="col-sm-2 my-auto d-block">
                                <button class="btn btn-primary-pk" >Buscar</button>
                                
                            </div>
                        </div>
                    </form>

                    <div class="table-responsive card card-outline  border-top-pk   shadow">
                        <?php if($historial->isNotEmpty()): ?>
                            <table class="table table-striped mt-3 ">
                                <thead class="p-3">
                                    <tr>
                                        <th>Usuario</th>
                                        <th>Fecha Realizada</th>
                                        <th>Fecha Inicial</th>
                                        <th>Fecha Final</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php $__currentLoopData = $historial; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <tr>
                                            <td><?php echo e($item->usuarioNom->nombre); ?></td>
                                            <td><?php echo e($item->fecha); ?></td>
                                            <td><?php echo e($item->fechaini); ?></td>
                                            <td><?php echo e($item->fechafin); ?></td>
                                        </tr>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                <?php else: ?>
                                    <div class="alert alert-dark m-4" role="alert">¡No se encuentra reportes generados del dia!
                                    </div>
                        <?php endif; ?>

                        </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </div>




        <script src="https://cdn.jsdelivr.net/npm/jquery@3.5.1/dist/jquery.slim.min.js"
            integrity="sha384-DfXdz2htPH0lsSSs5nCTpuj/zy4C+OGpamoFVy38MVBnE+IbbVYUew+OrCXaRkfj" crossorigin="anonymous">
        </script>
        <script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.11.7/dist/umd/popper.min.js"
            integrity="sha384-zYPOMqeu1DAVkHiLqWBUTcbYfZ8osu1Nd6Z89ify25QV9guujx43ITvfi12/QExE" crossorigin="anonymous">
        </script>
        <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha3/dist/js/bootstrap.min.js"
            integrity="sha384-Y4oOpwW3duJdCWv5ly8SCFYWqFDsfob/3GkgExXKV4idmbt98QcxXYs9UoXAB7BZ" crossorigin="anonymous">
        </script>
    </body>



    </body>

    </html>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('welcome', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\ProyectoParqueo\resources\views/loginuser/historial.blade.php ENDPATH**/ ?>